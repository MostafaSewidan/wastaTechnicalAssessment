<div class="tab-pane fade show active" id="list-instruction" role="tabpanel" aria-labelledby="list-instruction-list">
    <ul>
        <li>{{trans('file.While synchronizing, refrain from refreshing the page or leaving it.')}}</li>
        <li>{{trans('file.To obtain WooCommerce API details, navigate to WooCommerce -> Settings -> Advance -> REST API. Provide a description, select a user, and grant Read/Write Permission.')}}</li>
        <li>{{trans('file.In the WordPress permalink option, select Post Name as the permalinks option.')}}</li>
    </ul>
</div>
